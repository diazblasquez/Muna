/**
 * auth.js
 * -----------------------------------------------------------------------
 * Registro / login SIMULADO con localStorage, para usar mientras no haya
 * backend. Se comparte entre login.html, register.html, checkout.html y
 * a futuro la página de "cuenta".
 *
 * ⚠️ Las contraseñas quedan en texto plano en el navegador. Es aceptable
 * para maquetar y probar el flujo, pero cuando exista un backend real hay
 * que reemplazar estas funciones por llamadas a la API (fetch a /login,
 * /register) y jamás guardar la contraseña en el cliente.
 * -----------------------------------------------------------------------
 */
const Auth = (() => {
    const USERS_KEY = 'usuarios';
    const ACTIVE_USER_KEY = 'usuarioActivo';

    const getUsers = () => {
        try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; }
        catch { return []; }
    };
    const saveUsers = (users) => localStorage.setItem(USERS_KEY, JSON.stringify(users));
    const normalizeEmail = (email) => (email || '').trim().toLowerCase();

    const publicUser = (user) => ({
        id: user.id, nombre: user.nombre, apellido: user.apellido, email: user.email
    });

    const setActiveUser = (user) => {
        localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(publicUser(user)));
    };

    const registerUser = ({ nombre, apellido, email, password }) => {
        const emailNorm = normalizeEmail(email);
        if (!nombre || !apellido || !emailNorm || !password) {
            return { ok: false, error: 'Completá todos los campos.' };
        }
        const users = getUsers();
        if (users.some(u => u.email === emailNorm)) {
            return { ok: false, error: 'Ya existe una cuenta con ese email.' };
        }
        const nuevoUsuario = {
            id: Date.now().toString(36),
            nombre: nombre.trim(),
            apellido: apellido.trim(),
            email: emailNorm,
            password
        };
        users.push(nuevoUsuario);
        saveUsers(users);
        setActiveUser(nuevoUsuario);
        return { ok: true, user: publicUser(nuevoUsuario) };
    };

    const loginUser = (email, password) => {
        const emailNorm = normalizeEmail(email);
        const encontrado = getUsers().find(u => u.email === emailNorm);
        if (!encontrado || encontrado.password !== password) {
            return { ok: false, error: 'Email o contraseña incorrectos.' };
        }
        setActiveUser(encontrado);
        return { ok: true, user: publicUser(encontrado) };
    };

    const getActiveUser = () => {
        try { return JSON.parse(localStorage.getItem(ACTIVE_USER_KEY)) || null; }
        catch { return null; }
    };

    const logoutUser = () => localStorage.removeItem(ACTIVE_USER_KEY);
    const isLoggedIn = () => getActiveUser() !== null;

    return { registerUser, loginUser, getActiveUser, logoutUser, isLoggedIn };
})();
