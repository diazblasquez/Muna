window.addEventListener('DOMContentLoaded', () => {
    const navbar = document.querySelector('.nav');

    // 1. Scroll del Nav
    if (document.body.classList.contains('home-page')) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // 2. Animación de aparición para las categorías
        const opcionesObserver = {
            root: null,       
            rootMargin: '0px',
            threshold: 0.15   // La animación se activa cuando se ve el 15% del cuadrado
        };

        const categoriasObserver = new IntersectionObserver((entradas, observador) => {
            entradas.forEach(entrada => {
                // Si el elemento entra en la pantalla
                if (entrada.isIntersecting) {
                    entrada.target.classList.add('active');
                    // Dejamos de observarlo para que la animación solo ocurra una vez
                    observador.unobserve(entrada.target); 
                }
            });
        }, opcionesObserver);

        // Seleccionamos todos los cuadrados que tengan las nuevas clases
        const cuadrados = document.querySelectorAll('.reveal-left, .reveal-right');
        cuadrados.forEach(cuadrado => categoriasObserver.observe(cuadrado));
    }
});